import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  loggedIn = false;
  userId: string;
  token: string;
  role: string;
  user: string;
  isAdd :boolean;
  isEdit:boolean;
  constructor() { }

  isLoggedIn() {
    return this.loggedIn;
  }
  getIsAdded() {
    return this.isAdd;
  }
  setIsEdited(isEdit: boolean) {
    this.isEdit = isEdit;
  }
  getIsEdited() {
    return this.isEdit;
  }
  setIsAdded(isAdd: boolean) {
    this.isAdd = isAdd;
  }
  setLoggedIn(loggedIn: boolean) {
    this.loggedIn = loggedIn;
  }

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }
  public logout() {
    this.loggedIn = false;
  }

  public setRole(role: string) {
    this.role = role;
  }

  public getRole() {
    return this.role;
  }

  public setUser(user: string) {
    this.user = user;
  }

  public getUser() {
    return this.user;
  }
}
