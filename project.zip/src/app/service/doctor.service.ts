import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Doctor } from '../doctor/doctor/doctor';
import { UserAuthService } from './user-auth.service';
import { Medicare } from '../doctor/medicare';
import { BookAppointment } from '../patient/patient/book-appoitment';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  baseUrl = environment.baseUrl+'authentication-service/doctors';
  doctorUrl = environment.baseUrl+'doctor-service/';
  patientUrl = environment.baseUrl+'patient-service/';
  patientLength = 0;
  doctorApproval:boolean;

  constructor(private httpClient: HttpClient, private userAuthService: UserAuthService) { }

  addDoctor(doctor: Doctor): Observable<Doctor> {
    console.log("FROM USER SERVICE -> " + doctor)
    return this.httpClient.post<Doctor>(this.baseUrl, doctor);
  }
  getAllDoctorsForApproval():Observable<any[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get<Doctor[]>(this.baseUrl,httpOptions);
  }
  rejectDoctor(id:string){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken());
    return this.httpClient.put<void>(this.baseUrl+"/reject/"+id,{},httpOptions);
  }
  approveDoctor(id:string):Observable<void>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken());
    return this.httpClient.put<void>(this.patientUrl+"approve/"+id,{},httpOptions);
  }
  rejectAppoinment(id:string){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken());
    return this.httpClient.put<void>(this.patientUrl+"doctors/appointment/reject/"+id,id,httpOptions);
  }
  approveAppoinment(id:string):Observable<void>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken());
    return this.httpClient.put<void>(this.patientUrl+"doctors/appointment/accept/"+id,id,httpOptions);
  }
  getAllAppoinmentForApproval(doctorId:string):Observable<BookAppointment[]>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken());
    return this.httpClient.get<BookAppointment[]>(this.patientUrl+"doctors/appointment/"+doctorId,httpOptions);
  }
  getDoctor(doctorId: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get(this.doctorUrl + "doctors/" + doctorId, httpOptions);
  }
  getAllDoctor(): Observable<Doctor[]>  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get<Doctor[]>(this.patientUrl + "doctors", httpOptions);
  }
  getDoctorsForMedicareService(name:string): Observable<Doctor[]>  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get<Doctor[]>(this.patientUrl + "doctors/medicare/"+name, httpOptions);
  }
  getMedicareService(id: number): Observable<Medicare> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get<Medicare>(this.doctorUrl + "medicares/" + id, httpOptions);
  }
  getAllMedicareService(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get(this.patientUrl + "medicares", httpOptions);
  }

  getMedicareServiceForDoctor(doctorId: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get(this.doctorUrl + "medicares/doctor/" + doctorId, httpOptions);
  }

  public updateMedicareService(medicare: Medicare, doctorId: string): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken(),
      }),
    };
    return this.httpClient.put<void>(this.doctorUrl + "doctors/" + doctorId, medicare, httpOptions);
  }
  public addNewMedicareService(medicare: Medicare, doctorId: string): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken(),
      }),
    };
    return this.httpClient.post<void>(this.doctorUrl + "doctors/" + doctorId, medicare, httpOptions);
  }

  setNotification(length: number) {
    this.patientLength = length;
  }

  getNotification() {
    return this.patientLength;
  }

}
