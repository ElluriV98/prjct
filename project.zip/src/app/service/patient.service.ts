import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Patient } from '../patient/patient/patient';
import { AuthenticationService } from './authentication.service';
import { UserAuthService } from './user-auth.service';
import { BookAppointment } from '../patient/patient/book-appoitment';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class PatientService {
  // baseUrl = 'http://localhost:8910/patients';
  // patientUrl = 'http://localhost:8912/patients/';
  // getMedicareByDoctorAndServiceNameUrl = 'http://localhost:8912/medicares/doctor';
  baseUrl = environment.baseUrl+'authentication-service/patients';
  patientUrl = environment.baseUrl+'patient-service/patients/';
  getMedicareByDoctorAndServiceNameUrl = environment.baseUrl+'patient-service/medicares/doctor';
  patientLength = 0;
  patientApproval: boolean;
  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService, private userAuthService: UserAuthService) { }

  addPatient(patient: Patient): Observable<Patient> {
    console.log("FROM USER SERVICE -> " + patient)
    return this.httpClient.post<Patient>(this.baseUrl, patient);
  }
  getPatient(patientId: string): Observable<Patient> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get<Patient>(this.patientUrl + patientId, httpOptions);
  }
  getAllPatientForApproval(): Observable<any[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get<Patient[]>(this.baseUrl, httpOptions);
  }
  getAllPatient(): Observable<any[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.get<Patient[]>(this.patientUrl, httpOptions);
  }
  rejectPatient(id: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken());
    return this.httpClient.put<void>(this.baseUrl + "/reject/" + id, id, httpOptions);
  }
  getAllAppoinmentForPatient(patientId: string): Observable<BookAppointment[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken());
    return this.httpClient.get<BookAppointment[]>(this.patientUrl + "appointment/" + patientId, httpOptions);
  }
  approvePatient(id: string): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(this.userAuthService.getToken())
    console.log(this.baseUrl + "/approve/" + id, httpOptions);
    return this.httpClient.put<void>(this.baseUrl + "/approve/" + id, id, httpOptions);
  }
  bookAppointment(patientId: String, doctorId: string, medicareServiceId: number, bookingAppointment: BookAppointment): Observable<BookAppointment> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    console.log(bookingAppointment);
    return this.httpClient.post<BookAppointment>(this.patientUrl + patientId + "/" + doctorId + "/" + medicareServiceId, bookingAppointment, httpOptions);
  }
  setNotification(length: number) {
    this.patientLength = length;
  }
  deleteAppointment(id: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    };
    return this.httpClient.delete(this.patientUrl + id, httpOptions);
  }
  getMedicareByDoctorAndServiceName(doctorId: string, name: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.userAuthService.getToken()
      })
    }
    return this.httpClient.get(`${this.getMedicareByDoctorAndServiceNameUrl}/${doctorId}/${name}`, httpOptions);
  }
  getNotification() {
    return this.patientLength;
  }
}
