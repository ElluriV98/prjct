import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {  FormsModule, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './site/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { SignupComponent } from './site/signup/signup.component';
import { RouterModule } from '@angular/router';
import { DoctorComponent } from './doctor/doctor/doctor.component';
import { PatientComponent } from './patient/patient/patient.component';
import { HeaderComponent } from './site/header/header.component';
import { AdminComponent } from './admin/admin/admin.component';
import { MedicareComponent } from './doctor/medicare/medicare.component';
import { MedicareInfoComponent } from './doctor/medicare-info/medicare-info.component';
import { PatientMedicareInfoComponent } from './patient/patient-medicare-info/patient-medicare-info.component';
import { DoctorInfoComponent } from './patient/doctor-info/doctor-info.component';
import { BookComponent } from './patient/book/book.component';
import { AppointmentsComponent } from './doctor/appointments/appointments.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    DoctorComponent,
    PatientComponent,
    HeaderComponent,
    AdminComponent,
    MedicareComponent,
    MedicareInfoComponent,
    PatientMedicareInfoComponent,
    DoctorInfoComponent,
    BookComponent,
    AppointmentsComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
