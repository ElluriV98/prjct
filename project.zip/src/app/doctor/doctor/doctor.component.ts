import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { Doctor } from './doctor';
import { Medicare } from '../medicare';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Router } from '@angular/router';
import { BookAppointment } from 'src/app/patient/patient/book-appoitment';
import { Patient } from 'src/app/patient/patient/patient';
import { PatientService } from 'src/app/service/patient.service';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {
  doctor: Doctor;
  // doctorId: string;
  medicareService: Medicare[];
  appointments: BookAppointment[];
  // appointment:BookAppointment;
  patients:Patient[];
  service=true;
  newAppointment=false;
  appointment=false;
  add=false;
  isEmpty: boolean;
  constructor(private doctorService: DoctorService, private userAuthService: UserAuthService, private router: Router,private patientService:PatientService ) { }
  isDoctor() {
    if (this.userAuthService.getRole() == "doctor") {
      // this.doctorId = this.userAuthService.getUser();
      return true;
    } else {
      this.router.navigate(['/login']);
      this.userAuthService.loggedIn = false;
    }
  }
  ngOnInit() {
    const doctorId = this.userAuthService.getUser();
    this.patientService.getAllPatient().subscribe(data=>{
      this.patients=data;
    });
    this.doctorService.getDoctor(doctorId).subscribe(data => {
      this.doctor = data;
    });
    this.doctorService.getMedicareServiceForDoctor(doctorId).subscribe(data => {
      this.medicareService = data;
    });

  }
  showService(){
    this.service=true;
    this.newAppointment=false;
    this.appointment=false;
    this.add=false;
  }
  showNewAppointment(){
    this.service=false;
    this.newAppointment=true;
    this.appointment=false;
    this.add=false;
    this.doctorService.getAllAppoinmentForApproval(this.userAuthService.getUser()).subscribe(data => {
      this.appointments = data;
      if(this.appointments.length<=0){
        this.isEmpty=true;
      }else{
        this.isEmpty=false;
      }
    });
  }
  showAppointment(){
    this.service=false;
    this.newAppointment=false;
    this.appointment=true;
    this.add=false;
  }
  isAdd() {
    this.userAuthService.setIsAdded(true);
    this.service=false;
    this.newAppointment=false;
    this.appointment=false;
    this.add=true;
  }
  approveAppointment(id: string) {
    this.doctorService.approveAppoinment(id).subscribe(data => {
      this.doctorService.getAllAppoinmentForApproval(this.userAuthService.getUser()).subscribe(data => {
        this.appointments = data;
        if(this.appointments.length<=0){
          this.isEmpty=true;
        }else{
          this.isEmpty=false;
        }
        // this.patientService.setNotification(this.patients.length);
      })
    })
  }

  rejectAppointment(id: string) {
    this.doctorService.rejectAppoinment(id).subscribe(data => {
      this.doctorService.getAllAppoinmentForApproval(this.userAuthService.getUser()).subscribe(data => {
        this.appointments = data;
        if(this.appointments.length<=0){
          this.isEmpty=true;
        }else{
          this.isEmpty=false;
        }
      })
    });
  }
}
