import { Component, OnInit, Input } from '@angular/core';
import { BookAppointment } from 'src/app/patient/patient/book-appoitment';
import { Patient } from 'src/app/patient/patient/patient';
import { PatientService } from 'src/app/service/patient.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
@Input() appointment:BookAppointment;
patients:Patient[];
  constructor( private router: Router,private patientService:PatientService) { }

  ngOnInit() {
    this.patientService.getAllPatient().subscribe(data=>{
      this.patients=data;
    });
  }

}
