import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicareInfoComponent } from './medicare-info.component';

describe('MedicareInfoComponent', () => {
  let component: MedicareInfoComponent;
  let fixture: ComponentFixture<MedicareInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicareInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicareInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
