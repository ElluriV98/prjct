import { Component, OnInit, Input } from '@angular/core';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Medicare } from '../medicare';

@Component({
  selector: 'app-medicare-info',
  templateUrl: './medicare-info.component.html',
  styleUrls: ['./medicare-info.component.css']
})
export class MedicareInfoComponent implements OnInit {
  constructor(private userAuthService: UserAuthService) { }

  @Input() medicare: Medicare;

  ngOnInit() {

  }

  onEdit() {
    this.userAuthService.setIsEdited(true);
  }

}
