import { Component, OnInit } from '@angular/core';
import { Params, ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from 'src/app/service/doctor.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Medicare } from '../medicare';
import { UserAuthService } from 'src/app/service/user-auth.service';

@Component({
  selector: 'app-medicare',
  templateUrl: './medicare.component.html',
  styleUrls: ['./medicare.component.css']
})
export class MedicareComponent implements OnInit {
  editForm: FormGroup;
  serviceEdited: boolean;
  isAdd: boolean;
  isEdit: boolean;
  constructor(private doctorService: DoctorService, private fb: FormBuilder, private route: ActivatedRoute, private router: Router, private userAuthService: UserAuthService) { }

  ngOnInit() {
    this.serviceEdited = false;
    this.editForm = this.fb.group({
      id: [''],
      name: [''],
      description: [''],
      amount: [''],
      imageUrl: ['']
    });

    console.log(this.userAuthService.getIsEdited());
    if (this.userAuthService.getIsEdited() == true) {
      this.route.params.subscribe((params: Params) => {
        const medicareServiceId = params['id'];
        console.log(medicareServiceId);
        this.userAuthService.setIsEdited(false);
        this.doctorService.getMedicareService(medicareServiceId).subscribe((medicareService: Medicare) => {
          console.log(medicareService);
          if (medicareService) {
            this.editForm.patchValue({
              id: medicareServiceId,
              name: medicareService.name,
              description: medicareService.description,
              amount: medicareService.amount,
              imageUrl: medicareService.imageUrl
            });
          } else {
            this.router.navigate(['not-found']);
          }
        });
      });
    }
  }

  get name() {
    return this.editForm.get('name');
  }
  get description() {
    return this.editForm.get('description');
  }
  get amount() {
    return this.editForm.get('amount');
  }

  get imageUrl() {
    return this.editForm.get('imageUrl');
  }
  onSubmit() {
    this.isAdd = this.userAuthService.getIsAdded();
    this.isEdit = this.userAuthService.getIsEdited();
    const username = this.userAuthService.getUser();
    console.log(this.isEdit);
    console.log(this.isAdd);
    if (this.isEdit == true) {
      this.serviceEdited = true;
      console.log(username);
      this.doctorService.updateMedicareService(this.editForm.value, username).subscribe();
      this.userAuthService.setIsEdited(false);
      this.isEdit = this.userAuthService.getIsEdited();
      console.log(this.isEdit)
    }
    if (this.isAdd == true) {
      console.log(username);
      this.doctorService.addNewMedicareService(this.editForm.value, username).subscribe();
      this.userAuthService.setIsAdded(false);
      this.serviceEdited = true;
    }
  }

}
