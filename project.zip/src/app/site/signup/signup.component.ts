import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { PatientService } from 'src/app/service/patient.service';

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { Patient } from 'src/app/patient/patient/patient';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  isDoctor = false;
  isPatient = true;
  doctor: Doctor;
  patient: Patient;
  signupForm: FormGroup;
  error: string;
  constructor(private router: Router, private doctorService: DoctorService, private patientService: PatientService) { }

  ngOnInit() {
    {
      this.signupForm = new FormGroup({
        'patientId': new FormControl(null, [Validators.required, Validators.maxLength(10)]),
        'doctorId': new FormControl(null, [Validators.required, Validators.maxLength(10)]),
        'firstName': new FormControl(null, [Validators.required, Validators.pattern('^[A-Za-z]+$'), Validators.maxLength(50)]),
        'lastName': new FormControl(null, [Validators.required, Validators.pattern('^[A-Za-z]+$'), Validators.maxLength(50)]),
        'age': new FormControl(null, [Validators.required, Validators.maxLength(2), Validators.pattern('^[0-9]+$')]),
        'gender': new FormControl(null, [Validators.required]),
        'dateOfBirth': new FormControl(null),
        'contactNumber': new FormControl(null, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]),
        'altContactNumber': new FormControl(null, [Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]),
        'emailId': new FormControl(null, [Validators.required]),
        'password': new FormControl(null, [Validators.required]),
        'addressLine1': new FormControl(null, [Validators.required]),
        'city': new FormControl(null, [Validators.required, Validators.pattern('^[A-Za-z ]+$')]),
        'state': new FormControl(null, [Validators.required, Validators.pattern('^[A-Za-z ]+$')]),
        'zipCode': new FormControl(null, [Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern('^[0-9]+$')]),
        'degree': new FormControl(null, [Validators.required]),
        'speciality': new FormControl(null, [Validators.required]),
        'workHours': new FormControl(null, [Validators.required]),
        'hospitalName': new FormControl(null, [Validators.required])
      });
    }
  }
  get patientId() {
    return this.signupForm.get('patientId');
  }
  get doctorId() {
    return this.signupForm.get('doctorId');
  }
  get firstName() {
    return this.signupForm.get('firstName');
  }
  get lastName() {
    return this.signupForm.get('lastName');
  }
  get age() {
    return this.signupForm.get('age');
  }
  get gender() {
    return this.signupForm.get('gender');
  }
  get dateOfBirth() {
    return this.signupForm.get('dateOfBirth');
  }
  get contactNumber() {
    return this.signupForm.get('contactNumber');
  }
  get altContactNumber() {
    return this.signupForm.get('altContactNumber');
  }
  get emailId() {
    return this.signupForm.get('emailId');
  }
  get password() {
    return this.signupForm.get('password');
  }
  get addressLine1() {
    return this.signupForm.get('addressLine1');
  }
  get city() {
    return this.signupForm.get('city');
  }
  get state() {
    return this.signupForm.get('state');
  }
  get zipCode() {
    return this.signupForm.get('password');
  }
  get degree() {
    return this.signupForm.get('degree');
  }
  get speciality() {
    return this.signupForm.get('speciality');
  }
  get workHours() {
    return this.signupForm.get('workHours');
  }
  get hospitalName() {
    return this.signupForm.get('hospitalName');
  }
  onDoctorClick() {
    this.isDoctor = true;
    this.isPatient = false;
  }
  onPatientClick() {
    this.isDoctor = false;
    this.isPatient = true;
  }
  isEqual() : boolean{
    if (this.signupForm.get('contactNumber').value == this.signupForm.get('altContactNumber').value) {
      return true
    } else {
      return false;
    }
  }
  onSubmit() {
    console.log("In submit")
    console.log(this.signupForm.value);
    if (this.isDoctor) {
      this.doctor = this.signupForm.value;
      console.log(this.doctor);
      this.doctorService.addDoctor(this.signupForm.value).subscribe(
        (response) => {
          this.error = '';
          this.router.navigate(['/login']);
        },
        (responseError) => {
          this.error = responseError.error.message;
          console.log(this.error);
        });
    }
    if (this.isPatient) {
      this.patient = this.signupForm.value;
      console.log(this.patient);
      this.patientService.addPatient(this.signupForm.value).subscribe(
        (response) => {
          this.error = '';
          this.router.navigate(['/login']);
        },
        (responseError) => {
          this.error = responseError.error.message;
          console.log(this.error);
        });
    }
  }

}
