import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { DoctorService } from 'src/app/service/doctor.service';
import { PatientService } from 'src/app/service/patient.service';
import { AdminComponent } from 'src/app/admin/admin/admin.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  role: string;
  patientLength: number;
  doctorLength: number;
  constructor(private userAuthService: UserAuthService, private doctorService: DoctorService, private patientService: PatientService) { }

  ngOnInit() {
    this.patientLength = this.patientService.getNotification();
    this.doctorLength = this.doctorService.getNotification();
  }
  admin(){
    this.patientLength=this.patientService.getNotification();
    this.doctorLength=this.doctorService.getNotification();
    return this.userAuthService.getRole();

  }
  isAuthenticated() {
    // return this.authService.loggedIn;
    return this.userAuthService.loggedIn;
  }
  getRole() {
    this.role = this.userAuthService.getRole();
  }
  // isAdmin() {
  //   // return this.authService.isAdmin
  //   if (this.userAuthService.getRole() == 'ROLE_ADMIN') {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }
  getUser() {
    // return this.authService.userAuthenticated;
    return this.userAuthService.getUser();
  }
  patientRequest(){
    this.doctorService.doctorApproval=false;
    this.patientService.patientApproval=true;

  }
  doctorRequest(){
    this.doctorService.doctorApproval=true;
    this.patientService.patientApproval=false;

  }
  
  onSignOut() {
    // this.cartService.clearCart();
    this.userAuthService.logout();
  }
}
