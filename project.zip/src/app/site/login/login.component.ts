import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';

import { UserAuthService } from 'src/app/service/user-auth.service';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isLoginValid = true;
  error: string;
  loginForm: FormGroup;
  isDoctor = false;
  isPatient = true;
  isAdmin = false;
  constructor(private route: ActivatedRoute, private fb: FormBuilder, private router: Router, private authenticationService: AuthenticationService, private userAuthService: UserAuthService) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: [''],
      password: [''
        // Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')
      ]
    });

    // this.route.queryParams.subscribe((params: Params) => {
    //   this.authSource = params['from'];
    // });
  }

  get username() {
    return this.loginForm.get('username');
  }
  get password() {
    return this.loginForm.get('password');
  }
  onDoctorClick() {
    this.isDoctor = true;
    this.isPatient = false;
    this.isAdmin = false;
  }
  onPatientClick() {
    this.isDoctor = false;
    this.isPatient = true;
    this.isAdmin = false;
  }
  onAdminClick() {
    this.isDoctor = false;
    this.isPatient = false;
    this.isAdmin = true;
  }
  o
  onLogin() {
    const username = this.loginForm.value.username;
    const password = this.loginForm.value.password;
    console.log(username);
    console.log(password);
    this.authenticationService.authenticate(username, password).subscribe((data) => {
      console.log('success');
      console.log(data)
      this.userAuthService.setToken(data.token);
      this.userAuthService.setRole(data.role);
      this.userAuthService.setUser(data.user);
      // this.router.navigate(['/login']);
      const role = this.userAuthService.getRole();
      console.log(role);
      if (role == "doctor" && this.isDoctor) {
        console.log("doctor logged");
        this.userAuthService.setToken(data.token);
        this.userAuthService.loggedIn = true;
        this.router.navigate(['/doctor']);
      } else if (role == "patient"  && this.isPatient) {
        console.log("patient logged");
        this.userAuthService.setToken(data.token);
        this.userAuthService.loggedIn = true;
        this.router.navigate(['/patient']);
      } else if (role == "admin"  && this.isAdmin) {
        console.log("admin logged");
        this.userAuthService.loggedIn = true;
        this.userAuthService.setToken(data.token);
        this.router.navigate(['/admin']);
      } else {
        this.isLoginValid = false;
        this.error = "Invalid Username/Password";
      }
    },
      (error) => {
        console.log("error");
        this.isLoginValid = false;
        if (error.status == 401)
          this.error = "Invalid Username/Password";
      }
    );
  }

}
