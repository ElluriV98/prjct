import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';
import { AdminComponent } from './admin/admin/admin.component';
import { PatientComponent } from './patient/patient/patient.component';
import { DoctorComponent } from './doctor/doctor/doctor.component';
import { MedicareComponent } from './doctor/medicare/medicare.component';
import { AuthGuard } from './service/auth.guard';



const routes: Routes = [
  { path: 'login', component: LoginComponent  },
  { path: 'signup', component: SignupComponent },
  { path: 'admin', component: AdminComponent, canActivate: [AuthGuard] },
  { path: 'patient', component: PatientComponent , canActivate: [AuthGuard]},
  { path: 'doctor', component: DoctorComponent, canActivate: [AuthGuard] },
  { path: 'medicare', component: MedicareComponent , canActivate: [AuthGuard]},
  { path: 'medicare/:id', component: MedicareComponent, canActivate: [AuthGuard] },
  {path: '', redirectTo: 'login', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
