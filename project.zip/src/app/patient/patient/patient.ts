export interface Patient {
    id: number;
    patientId: string;
    firstName: string;
    lastName: string;
    age: number;
    gender: string;
    dateOfBirth: string;
    contactNumber: number;
    altContactNumber: number;
    emailId: string;
    password: string;
    adressLine1: string;
    city: string;
    state: string;
    zipCode: number;
}