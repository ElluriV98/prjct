export interface BookAppointment {
    id:number;
    patientId:string;
    doctorId:string;
    medicareServiceId:number;
    appointmentDate: string;
    approve:boolean;
    reject:boolean;
}