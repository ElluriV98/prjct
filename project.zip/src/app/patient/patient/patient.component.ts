import { Component, OnInit } from '@angular/core';
import { Medicare } from 'src/app/doctor/medicare';
import { DoctorService } from 'src/app/service/doctor.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { BookAppointment } from './book-appoitment';
import { PatientService } from 'src/app/service/patient.service';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {
  medicareService: Medicare[];
  doctors: Doctor[];
  doctor: boolean;
  medicare = false;
  appointment = true;
  appointments: BookAppointment[];
  book: boolean;
  constructor(private doctorService: DoctorService, private userAuthService: UserAuthService, private patientService: PatientService) { }

  ngOnInit() {
    const patientId = this.userAuthService.getUser();
    this.doctorService.getAllMedicareService().subscribe(data => {
      this.medicareService = data;
    });
    this.doctorService.getAllDoctor().subscribe(data => {
      this.doctors = data;
    });
    this.patientService.getAllAppoinmentForPatient(this.userAuthService.getUser()).subscribe(data => {
      this.appointments = data;
    });
  }

  showMedicares() {
    this.book=false; 
    this.doctor = false
    this.appointment = false;
    this.medicare = true;
    
  }

  showDoctors() {
    this.doctor = true
    this.medicare = false;
    this.appointment = false;
    this.book=false; 
  }
  bookAppointment(){
    this.doctor = false
    this.medicare = false;
    this.appointment = false;
    this.book=true; 
  }
  showAppointment() {
    this.doctor = false
    this.medicare = false;
    this.appointment = true;
    this.book=false;
    this.patientService.getAllAppoinmentForPatient(this.userAuthService.getUser()).subscribe(data => {
      this.appointments = data;
    });
  }
  onDelete(id: number) {
    this.patientService.deleteAppointment(id).subscribe(data=>{
      this.patientService.getAllAppoinmentForPatient(this.userAuthService.getUser()).subscribe(data => {
        this.appointments = data;
      });
    });
    
  }
}
// this.patientService.getAllAppoinmentForPatient(this.userAuthService.getUser()).subscribe(data => {
//   this.appointments = data
//   console.log(this.appointments);
// });