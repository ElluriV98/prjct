import { Component, OnInit, Input } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { Medicare } from 'src/app/doctor/medicare';
import { FormGroup, FormControl } from '@angular/forms';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { PatientService } from 'src/app/service/patient.service';
import { BookAppointment } from '../patient/book-appoitment';
import { UserAuthService } from 'src/app/service/user-auth.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  @Input()book:boolean;
  medicares: Medicare[];
  bookingForm: FormGroup;
  doctors: Doctor[]
  bookAppointment: BookAppointment;
  id:number;
  doctorId:string;
  patientId:string;
  doctorMedicare:Medicare;
  clickMedicare=false;
  clickDoctor=false;
  constructor(private doctorService: DoctorService, private patientService: PatientService,private userAuthService:UserAuthService) { }

  ngOnInit() {
    this.patientId=this.userAuthService.getUser();
    this.doctorService.getAllMedicareService().subscribe(data => {
      this.medicares = data;
    });
    this.doctorService.getMedicareService(1).subscribe(data=>{
      this.doctorMedicare=data;
    });
    this.doctorService.getAllDoctor().subscribe(data => {
      this.doctors = data;
    })
    this.bookingForm = new FormGroup({
      'medicareList': new FormControl(null),
      'doctorList': new FormControl(null),
      'appointmentDate': new FormControl(null)
    });
  }
  get medicareList() {
    return this.bookingForm.get('medicareList');
  }
  get doctorList() {
    return this.bookingForm.get('doctorList');
  }
  get appointmentDate() {
    return this.bookingForm.get('appointmentDate');
  }
  onMedicare(event:any) {
    this.clickMedicare=true
  console.log("on Medicare");
  console.log(event);
  this.id=event.id;
    this.doctorService.getDoctorsForMedicareService(event.name).subscribe(data => {
      this.doctors = data;
     this.doctorService.getMedicareService(this.id).subscribe(data=>{
      this.doctorMedicare=data;
     })
    });
  }
  onDoctor(event:any) {
    this.clickDoctor=true;
    console.log("on Medicare");
    console.log(event);
    this.doctorId=event.doctorId;
    this.patientService.getMedicareByDoctorAndServiceName(this.doctorId,this.doctorMedicare.name).subscribe(data=>{
      this.doctorMedicare=data;
    })
    }
  onSubmitbookingForm(bookingForm: FormGroup,medicare:Medicare) {
    this.bookAppointment = this.bookingForm.value
    this.patientService.bookAppointment(this.patientId,this.doctorId,this.id,bookingForm.value).subscribe();
    console.log(this.id)
  }
}
