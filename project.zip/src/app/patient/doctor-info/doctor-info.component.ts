import { Component, OnInit, Input } from '@angular/core';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { DoctorService } from 'src/app/service/doctor.service';
import { Medicare } from 'src/app/doctor/medicare';
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { BookAppointment } from '../patient/book-appoitment';
import { PatientService } from 'src/app/service/patient.service';

@Component({
  selector: 'app-doctor-info',
  templateUrl: './doctor-info.component.html',
  styleUrls: ['./doctor-info.component.css']
})
export class DoctorInfoComponent implements OnInit {
  @Input() doctor: Doctor;
  medicareService: Medicare[]
  showMedicare = false;
  book = false;
  bookDate: String
  bookingForm: FormGroup;
  doctorId: string;
  patientId: string;
  medicareServiceId: number;
  bookAppointment: BookAppointment;
  show=false;
  constructor(private patientService: PatientService, private doctorService: DoctorService, private fb: FormBuilder, private userAuthService: UserAuthService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.patientId = this.userAuthService.getUser();
    this.bookingForm = this.fb.group({
      appointmentDate: ['']
    });
  }
  showMedicares() {
    this.show=true;
    this.doctorService.getMedicareServiceForDoctor(this.doctor.doctorId).subscribe(data => {
      this.medicareService = data;
      console.log(this.medicareService);
      this.showMedicare = true;
      this.doctorId = this.doctor.doctorId;
    });
  }
  hideMedicares() {
    this.show=false;
  }
  get appointmentDate() {
    return this.bookingForm.get('appointmentDate');
  }
  onBook() {
    this.book = true;
  }
  medicareId(id: number) {
    this.medicareServiceId = id;
    console.log(id);
  }
  onBookAppointment() {
    const bookingDate = this.bookingForm.value.bookingDate;
    // this.bookAppointment.bookingDate = this.bookingForm.value.bookingDate;

    console.log(bookingDate);
    // console.log(this.medicareServiceId);
    console.log(this.doctorId)
    // console.log(password);
    this.patientService.bookAppointment(this.patientId, this.doctorId, this.medicareServiceId, this.bookingForm.value).subscribe();
  }
}
