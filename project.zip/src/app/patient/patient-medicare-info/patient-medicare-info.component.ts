import { Component, OnInit, Input } from '@angular/core';
import { Medicare } from 'src/app/doctor/medicare';
import { DoctorService } from 'src/app/service/doctor.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { PatientService } from 'src/app/service/patient.service';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-patient-medicare-info',
  templateUrl: './patient-medicare-info.component.html',
  styleUrls: ['./patient-medicare-info.component.css']
})
export class PatientMedicareInfoComponent implements OnInit {
  @Input() medicare: Medicare;
  doctorList: Doctor[];
  bookingForm: FormGroup;
  patientId: String;
  doctorId: string;
  medicareServiceId: number;
  showDoctor=false;
  doctorMedicare: Medicare;
  constructor(private doctorService: DoctorService, private userAuthService: UserAuthService, private patientService: PatientService, private fb: FormBuilder) { }
  descriptions = false;
  ngOnInit() {
  this.patientId = this.userAuthService.getUser();
    this.bookingForm = this.fb.group({
      appointmentDate: ['']
    });
  }
  hideDescription() {
    this.descriptions = false;
  }

  // showDescription() {
  //   this.description = true;
  // }
  showDoctors() {
    console.log(this.medicare.name);
    this.doctorService.getDoctorsForMedicareService(this.medicare.name).subscribe(data => {
      this.doctorList = data;
      console.log(this.doctorList);
      this.showDoctor=true;
      this.descriptions = false;
    })
  }
  get appointmentDate() {
    return this.bookingForm.get('appointmentDate');
  }
  showDescription(doctorId:string,name:string){
    this.descriptions = true;
    this.patientService.getMedicareByDoctorAndServiceName(doctorId,name).subscribe(data=>{
     this.doctorMedicare=data;
    //  console.log(i);
    });
  }
  onBookAppointment(doctorId:string, id:number) {
    const bookingDate = this.bookingForm.value.bookingDate;
    // this.bookAppointment.bookingDate = this.bookingForm.value.bookingDate;

    console.log(bookingDate);
    // console.log(this.medicareServiceId);
    console.log(this.doctorId)
    // console.log(password);
    this.patientService.bookAppointment(this.patientId, doctorId, id, this.bookingForm.value).subscribe();
  }


}

