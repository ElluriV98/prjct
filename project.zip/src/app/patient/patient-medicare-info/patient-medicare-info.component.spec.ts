import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientMedicareInfoComponent } from './patient-medicare-info.component';

describe('PatientMedicareInfoComponent', () => {
  let component: PatientMedicareInfoComponent;
  let fixture: ComponentFixture<PatientMedicareInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientMedicareInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientMedicareInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
