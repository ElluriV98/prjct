import { Component, OnInit } from '@angular/core';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { DoctorService } from 'src/app/service/doctor.service';
import { PatientService } from 'src/app/service/patient.service';
import { Patient } from 'src/app/patient/patient/patient';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  doctors: Doctor[];
  patients: Patient[];
  // isPatient=false;
  // isDoctor=false;
  constructor(private doctorService: DoctorService, private patientService: PatientService) { }

  ngOnInit() {
    this.patientService.getAllPatientForApproval().subscribe(data=>{
      this.patients=data;
      console.log(this.patients.length);
      this.patientService.setNotification(this.patients.length);
    });
    this.doctorService.getAllDoctorsForApproval().subscribe(data=>{
      this.doctors=data;
      console.log(this.doctors.length);
      this.doctorService.setNotification(this.doctors.length);
    })
  }

  approveDoctor(id: string) {
    this.doctorService.approveDoctor(id).subscribe(data => {
      this.doctorService.getAllDoctorsForApproval().subscribe(data => {
        this.doctors = data;
        this.doctorService.setNotification(this.doctors.length);
      })
    })
  }
  rejectDoctor(id: string) {
    this.doctorService.rejectDoctor(id).subscribe(data => {
      this.doctorService.getAllDoctorsForApproval().subscribe(data => {
        this.doctors = data;
        this.doctorService.setNotification(this.doctors.length);
      });
    });
  }
  approvePatient(id: string) {
    this.patientService.approvePatient(id).subscribe(data => {
      this.patientService.getAllPatientForApproval().subscribe(data => {
        this.patients = data;
        this.patientService.setNotification(this.patients.length);
      })
    })
  }

  rejectPatient(id: string) {
    this.patientService.rejectPatient(id).subscribe(data => {
      this.patientService.getAllPatientForApproval().subscribe(data => {
        this.patients = data;
        this.patientService.setNotification(this.patients.length);
      })
    });
  }
  isDoctor(){
    return this.doctorService.doctorApproval;
  }
  isPatient(){
    return this.patientService.patientApproval;
  }
}
